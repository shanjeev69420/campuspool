# College Vehicle Pooling App

## Goal
Create a single student-focused pooling app where college students can publish car or bike rides, discover routes to campus, and reserve available seats.

## Users
- Student drivers publish and manage rides using their own cars or bikes.
- Student riders browse suitable rides, inspect routes, and manage seat bookings.
- The same student can switch naturally between driver and rider activities.

## App structure
- Use a top navigation bar for four destinations: Discover, Publish Ride, My Trips, and Bookings.
- Personalize relevant views with the signed-in student's name and identity.

## Pages and features
- **Discover:** Search and filter upcoming rides by origin, destination, date, vehicle type, and availability; show compact ride cards with driver, departure, fare contribution, and seats.
- **Ride details:** Show vehicle and driver summary, available capacity, pickup timeline, a polished non-interactive map-style route preview, booking mode, and seat request action.
- **Publish Ride:** Let a driver choose car or bike, enter vehicle details, departure schedule, origin, campus destination, intermediate pickup stops, seat capacity, contribution amount, and instant-versus-approval booking.
- **My Trips:** Show rides the student has published, booking demand, remaining capacity, and controls to edit or cancel upcoming rides.
- **Bookings:** Show requested, confirmed, rejected, completed, and cancelled bookings with actions to cancel eligible requests.
- **Approval workflow:** For approval-based rides, let the driver accept or reject pending seat requests; instant rides confirm while capacity remains.
- **Feedback:** Provide clear success/error notifications, loading states, empty states, and safeguards against overbooking.

## Data sources
- Use the Power Apps user context for the signed-in student's identity; no external connector is required.
- Store app-owned records in draft in-memory tables for the initial build.

## Data entities
- Student Profile
- Vehicle
- Ride
- Route Stop
- Booking

## Core rules
- Cars can offer multiple seats; bikes can offer one passenger seat.
- A ride cannot accept bookings beyond its published capacity.
- Students cannot book their own ride.
- Booking status follows the ride's selected instant or driver-approval mode.
- Cancelling a confirmed booking restores availability.
- Route stops retain their pickup order and estimated time.

## Design direction
- Use a crisp, utilitarian campus-transit aesthetic with deep navy surfaces, energetic teal accents, and warm amber highlights.
- Favor dense, scannable cards, route lines, stop markers, vehicle icons, and clear status badges over marketing-style content.
- Support responsive desktop and mobile layouts with accessible contrast and restrained motion.

## Scope boundaries
- Include only browse, route preview, publish, book/cancel, driver approval, and personal trip/booking management.
- Do not include live GPS tracking, turn-by-turn navigation, payments, messaging, administration, ratings, or a live map provider in this release.

## Acceptance criteria
- Students can publish both car and bike rides with valid capacity and ordered route stops.
- Students can discover rides, inspect route details, and request available seats.
- Instant bookings confirm immediately; approval-based requests remain pending until the driver acts.
- Booking and ride cancellations update seat availability consistently.
- Personal views distinguish rides the student drives from rides they booked.
- The visual route preview communicates origin, pickup stops, destination, and estimated timing without external map credentials.
