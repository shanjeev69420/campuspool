# Campus Vehicle Pooling

## Overview
CampusPool is a rebuilt, college-verified ride-sharing workspace for Chennai students. Drivers publish spare car or bike seats for trips to college or home, set a fee per seat, and decide whether requests need approval; passengers find same-college routes, provide their own pickup area, and request one or more seats.

## Access
Every new session starts with college ID verification using the student's name, Chennai college, register number, and ID expiry. Logout removes the active session and returns immediately to verification.

## Core workspaces
- **Book a ride:** Filter same-college rides by area, vehicle, and direction, then request seats with a passenger-provided pickup area.
- **Publish a ride:** Select direction, vehicle, date, time, available seats, booking mode, and a driver-set fee per seat. Published rides immediately appear in ride discovery.
- **My bookings:** Track pending and confirmed requests, pickup details, seat count, total fare, and cancellations.
- **My rides:** Review published trips, accept or decline passenger requests, and cancel upcoming rides.

## Design direction
A crisp Chennai transit aesthetic combines deep coastal navy, energetic teal, and warm amber. Dense but readable cards, strong status cues, and separate passenger and driver workspaces keep the hackathon flow easy to demonstrate.

## Release boundaries
The app uses local college-ID validation and draft in-memory tables for the demo. It does not include live GPS, map navigation, payment collection, chat, ratings, or automated college-system verification; displayed fares are settled outside the app.