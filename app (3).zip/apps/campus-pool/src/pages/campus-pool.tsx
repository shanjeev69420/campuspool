import { useMemo, useState, type ChangeEvent, type FormEvent } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Bike, CalendarDays, Car, Check, ChevronRight, IndianRupee, Clock3, IdCard, LogOut, MapPin, Plus, Route, Search, ShieldCheck, TicketCheck, Users, X } from 'lucide-react';
import { motion } from 'motion/react';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { CollegeIdGate, type CollegeIdentity } from '@/components/college-id-gate';
import { HAS_IN_MEMORY_TABLES, useBookingList, useCreateBooking, useCreateRide, useCreateStudentProfile, useCreateVehicle, useRideList, useUpdateBooking, useUpdateRide, useVehicleList } from '@/generated/hooks';
import { InMemoryDataBanner } from '@/generated/components/in-memory-data-banner';
import type { Booking, BookingStatusKey } from '@/generated/models/booking-model';
import type { Ride } from '@/generated/models/ride-model';
import type { Vehicle } from '@/generated/models/vehicle-model';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Empty, EmptyDescription, EmptyHeader, EmptyTitle } from '@/components/ui/empty';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';

const SESSION_KEY = 'campus-pool-session-v3';
type Page = 'book' | 'publish' | 'bookings' | 'rides';
type Direction = 'ToCollege' | 'FromCollege';

const pagePath: Record<Page, string> = { book: '/', publish: '/publish', bookings: '/bookings', rides: '/my-rides' };
const formatTripDate = (value: string) => format(new Date(value), 'EEE, dd MMM · h:mm a');
const bookingBadge = (status: BookingStatusKey) => status === 'Confirmed' ? 'default' : status === 'Pending' ? 'secondary' : 'destructive';

function CampusPoolPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const page: Page = location.pathname === '/publish' ? 'publish' : location.pathname === '/bookings' ? 'bookings' : location.pathname === '/my-rides' ? 'rides' : 'book';
  const [identity, setIdentity] = useState<CollegeIdentity | undefined>(() => {
    const saved = sessionStorage.getItem(SESSION_KEY);
    if (!saved) return undefined;
    try {
      const parsed = JSON.parse(saved) as CollegeIdentity;
      return parsed.profileId ? parsed : undefined;
    } catch {
      sessionStorage.removeItem(SESSION_KEY);
      return undefined;
    }
  });
  const [selectedRide, setSelectedRide] = useState<Ride>();
  const [pickupArea, setPickupArea] = useState('');
  const [seatCount, setSeatCount] = useState(1);
  const [search, setSearch] = useState('');
  const [vehicleFilter, setVehicleFilter] = useState<'all' | 'Car' | 'Bike'>('all');
  const [directionFilter, setDirectionFilter] = useState<'all' | Direction>('all');
  const [publishDirection, setPublishDirection] = useState<Direction>('ToCollege');
  const [publishVehicle, setPublishVehicle] = useState<'Car' | 'Bike'>('Car');
  const [bookingMode, setBookingMode] = useState<'Approval' | 'Instant'>('Approval');
  const [travelDate, setTravelDate] = useState<Date>();
  const [departureTime, setDepartureTime] = useState('07:30');

  const { data: rideRows = [], isLoading } = useRideList();
  const { data: vehicleRows = [] } = useVehicleList();
  const { data: bookingRows = [] } = useBookingList();
  const createProfile = useCreateStudentProfile();
  const createRide = useCreateRide();
  const createVehicle = useCreateVehicle();
  const createBooking = useCreateBooking();
  const updateRide = useUpdateRide();
  const updateBooking = useUpdateBooking();

  const rides = useMemo(() => rideRows.filter((ride: Ride | null): ride is Ride => Boolean(ride?.id && ride.vehicle?.id)), [rideRows]);
  const vehicles = useMemo(() => vehicleRows.filter((vehicle: Vehicle | null): vehicle is Vehicle => Boolean(vehicle?.id)), [vehicleRows]);
  const bookings = useMemo(() => bookingRows.filter((booking: Booking | null): booking is Booking => Boolean(booking?.id && booking.ride?.id)), [bookingRows]);
  const student = { id: identity?.profileId ?? '', fullName: identity?.studentName ?? '' };
  const myRides = rides.filter((ride: Ride) => ride.driverStudent?.id === student.id);
  const myBookings = bookings.filter((booking: Booking) => booking.riderStudent?.id === student.id);
  const rideFor = (booking: Booking) => rides.find((ride: Ride) => ride.id === booking.ride?.id);

  const visibleRides = useMemo(() => rides.filter((ride: Ride) => {
    const vehicle = vehicles.find((item: Vehicle) => item.id === ride.vehicle?.id);
    const college = identity?.college.toLowerCase() ?? '';
    const text = `${ride.origin ?? ''} ${ride.campusDestination ?? ''} ${ride.rideName ?? ''}`.toLowerCase();
    return ride.statusKey === 'Upcoming' && ride.availableSeats > 0 && text.includes(college) && text.includes(search.trim().toLowerCase()) && (vehicleFilter === 'all' || vehicle?.vehicleTypeKey === vehicleFilter) && (directionFilter === 'all' || ride.rideDirectionKey === directionFilter);
  }), [rides, vehicles, identity, search, vehicleFilter, directionFilter]);

  const verifyStudent = async (access: CollegeIdentity) => {
    const profile = await createProfile.mutateAsync({ fullName: access.studentName, collegeName: access.college, email: `${access.registerNumber.toLowerCase().replace(/[^a-z0-9]/g, '')}@student.example.com` });
    const verified = { ...access, profileId: profile.id };
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(verified));
    setIdentity(verified);
    navigate('/', { replace: true });
  };

  const logout = () => {
    sessionStorage.removeItem(SESSION_KEY);
    setIdentity(undefined);
    setSelectedRide(undefined);
    setSearch('');
    navigate('/', { replace: true });
    toast.info('Logged out. Verify your college ID to continue.');
  };

  const publishRide = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!identity || !travelDate) { toast.warning('Choose a travel date.'); return; }
    const form = new FormData(event.currentTarget);
    const area = String(form.get('area') ?? '').trim();
    const seatsInput = Number(form.get('seats'));
    const fee = Number(form.get('fee'));
    if (!area) { toast.warning('Enter your starting or drop-off area.'); return; }
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(departureTime)) { toast.warning('Choose a departure time.'); return; }
    const [hours, minutes] = departureTime.split(':').map(Number);
    const departure = new Date(travelDate);
    departure.setHours(hours, minutes, 0, 0);
    if (departure.getTime() <= Date.now()) { toast.warning('Choose a future departure.'); return; }
    const seats = publishVehicle === 'Bike' ? 1 : seatsInput;
    if (!Number.isInteger(seats) || seats < 1 || seats > 6) { toast.warning('Choose between 1 and 6 empty seats.'); return; }
    if (!Number.isFinite(fee) || fee < 0) { toast.warning('Enter a valid per-seat fee.'); return; }
    const origin = publishDirection === 'ToCollege' ? area : identity.college;
    const destination = publishDirection === 'ToCollege' ? identity.college : area;
    try {
      let vehicle = vehicles.find((item: Vehicle) => item.ownerStudent?.id === student.id && item.vehicleTypeKey === publishVehicle);
      if (!vehicle) vehicle = await createVehicle.mutateAsync({ vehicleName: `${student.fullName}'s ${publishVehicle}`, vehicleTypeKey: publishVehicle, ownerStudent: student, make: 'Student vehicle', model: publishVehicle, color: 'Not specified', registrationNumber: `CP-${student.id.slice(-6).toUpperCase()}`, passengerCapacity: publishVehicle === 'Bike' ? 1 : Math.max(4, seats) });
      if (!vehicle?.id) throw new Error('Vehicle setup failed.');
      await createRide.mutateAsync({ rideName: `${origin} to ${destination}`, driverStudent: student, vehicle: { id: vehicle.id, vehicleName: vehicle.vehicleName }, origin, campusDestination: destination, rideDirectionKey: publishDirection, departureDateAndTime: departure.toISOString(), contributionAmount: fee, totalSeats: seats, availableSeats: seats, bookingModeKey: bookingMode, statusKey: 'Upcoming', createdDateAndTime: new Date().toISOString() });
      await queryClient.refetchQueries({ queryKey: ['ride-list'] });
      toast.success('Ride published and listed on Book a ride.');
      navigate('/', { replace: true });
    } catch (error: unknown) { toast.error(error instanceof Error ? error.message : 'Unable to publish this ride.'); }
  };

  const bookRide = async () => {
    if (!selectedRide?.id || !identity) return;
    if (selectedRide.driverStudent?.id === student.id) { toast.warning('You cannot book your own ride.'); return; }
    if (!pickupArea.trim()) { toast.warning('Enter your pickup area.'); return; }
    if (seatCount < 1 || seatCount > selectedRide.availableSeats) { toast.warning('Choose an available seat count.'); return; }
    if (myBookings.some((booking: Booking) => booking.ride?.id === selectedRide.id && ['Pending', 'Confirmed'].includes(booking.statusKey))) { toast.warning('You already requested this ride.'); return; }
    const status: BookingStatusKey = selectedRide.bookingModeKey === 'Instant' ? 'Confirmed' : 'Pending';
    try {
      await createBooking.mutateAsync({ bookingName: `${student.fullName} · ${selectedRide.rideName}`, ride: { id: selectedRide.id, rideName: selectedRide.rideName }, riderStudent: student, seatsRequested: seatCount, fareAmount: seatCount * (selectedRide.contributionAmount ?? 0), pickupPoint: pickupArea.trim(), statusKey: status, requestedDateAndTime: new Date().toISOString() });
      if (status === 'Confirmed') await updateRide.mutateAsync({ id: selectedRide.id, changedFields: { availableSeats: selectedRide.availableSeats - seatCount } });
      toast.success(status === 'Confirmed' ? 'Ride booked.' : 'Request sent to the driver.');
      setSelectedRide(undefined);
      setPickupArea('');
      setSeatCount(1);
      navigate('/bookings');
    } catch (error: unknown) { toast.error(error instanceof Error ? error.message : 'Unable to book this ride.'); }
  };

  const reviewBooking = async (booking: Booking, status: BookingStatusKey) => {
    const ride = rideFor(booking);
    if (!ride) { toast.error('Ride details are unavailable.'); return; }
    try {
      await updateBooking.mutateAsync({ id: booking.id, changedFields: { statusKey: status, reviewedDateAndTime: new Date().toISOString(), reviewedBy: student } });
      if (status === 'Confirmed') await updateRide.mutateAsync({ id: ride.id, changedFields: { availableSeats: Math.max(0, ride.availableSeats - booking.seatsRequested) } });
      if (status === 'Cancelled' && booking.statusKey === 'Confirmed') await updateRide.mutateAsync({ id: ride.id, changedFields: { availableSeats: Math.min(ride.totalSeats, ride.availableSeats + booking.seatsRequested) } });
      toast.success(`Booking ${status.toLowerCase()}.`);
    } catch (error: unknown) { toast.error(error instanceof Error ? error.message : 'Unable to update booking.'); }
  };

  if (!identity) return <CollegeIdGate onVerified={verifyStudent} />;

  const nav = [
    { page: 'book' as const, label: 'Book a ride', icon: Search },
    { page: 'publish' as const, label: 'Publish a ride', icon: Plus },
    { page: 'bookings' as const, label: 'My bookings', icon: TicketCheck },
    { page: 'rides' as const, label: 'My rides', icon: Route },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-30 border-b bg-card text-card-foreground">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3">
          <Link to="/" className="flex items-center gap-3"><span className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground"><Route className="size-5" /></span><span><strong className="block leading-tight">CampusPool</strong><small className="hidden text-muted-foreground sm:block">{identity.college}</small></span></Link>
          <nav className="flex items-center gap-1 overflow-x-auto" aria-label="Primary navigation">{nav.map(({ page: itemPage, label, icon: Icon }) => <Button key={itemPage} asChild size="sm" variant={page === itemPage ? 'default' : 'ghost'}><Link to={pagePath[itemPage]}><Icon className="size-4" /><span className="hidden lg:inline">{label}</span></Link></Button>)}</nav>
          <Button variant="outline" size="sm" onClick={logout}><LogOut className="size-4" /><span className="hidden sm:inline">Logout</span></Button>
        </div>
      </header>
      <main className="mx-auto max-w-7xl px-4 py-6">
        <InMemoryDataBanner show={HAS_IN_MEMORY_TABLES} message="Demo mode: data resets with the preview environment." className="mb-5 bg-accent text-accent-foreground border-accent-foreground" />

        {page === 'book' && <section>
          <div className="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><Badge variant="secondary">Verified for {identity.college}</Badge><h1 className="mt-2 text-2xl font-bold">Find a ride with a college mate</h1><p className="text-muted-foreground">Choose a route, enter your pickup area, and request the seats you need.</p></div><Button asChild><Link to="/publish"><Plus className="size-4" />Offer a ride</Link></Button></div>
          <Card className="mb-6"><CardContent className="grid gap-4 p-4 md:grid-cols-[1fr_180px_190px]"><div><Label htmlFor="route-search">Area or route</Label><div className="relative mt-2"><MapPin className="absolute left-3 top-2.5 size-4 text-muted-foreground" /><Input id="route-search" className="pl-9" value={search} onChange={(event: ChangeEvent<HTMLInputElement>) => setSearch(event.target.value)} placeholder="Adyar, Guindy, Tambaram..." /></div></div><div><Label>Vehicle</Label><Select value={vehicleFilter} onValueChange={(value: 'all' | 'Car' | 'Bike') => setVehicleFilter(value)}><SelectTrigger className="mt-2 w-full"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Car or bike</SelectItem><SelectItem value="Car">Car</SelectItem><SelectItem value="Bike">Bike</SelectItem></SelectContent></Select></div><div><Label>Direction</Label><Select value={directionFilter} onValueChange={(value: 'all' | Direction) => setDirectionFilter(value)}><SelectTrigger className="mt-2 w-full"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">To and from college</SelectItem><SelectItem value="ToCollege">Going to college</SelectItem><SelectItem value="FromCollege">Coming home</SelectItem></SelectContent></Select></div></CardContent></Card>
          <div className="mb-3 flex items-center justify-between"><h2 className="text-lg font-bold">Available rides</h2><span className="text-sm text-muted-foreground">{visibleRides.length} matches</span></div>
          {isLoading ? <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">{[1, 2, 3].map((item: number) => <Skeleton key={item} aria-hidden="true" className="h-72" />)}</div> : visibleRides.length === 0 ? <Empty className="rounded-xl border py-16"><EmptyHeader><EmptyTitle>No matching rides</EmptyTitle><EmptyDescription>Try another area or publish a ride for your route.</EmptyDescription></EmptyHeader></Empty> : <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">{visibleRides.map((ride: Ride) => {
            const vehicle = vehicles.find((item: Vehicle) => item.id === ride.vehicle?.id);
            const VehicleIcon = vehicle?.vehicleTypeKey === 'Bike' ? Bike : Car;
            const ownRide = ride.driverStudent?.id === student.id;
            return <motion.article key={ride.id} whileHover={{ y: -3 }} transition={{ duration: 0.2, ease: 'easeOut' as const }}><Card className="h-full overflow-hidden"><CardHeader className="border-b"><div className="flex items-start justify-between gap-3"><span className="flex size-11 items-center justify-center rounded-xl bg-primary text-primary-foreground"><VehicleIcon className="size-5" /></span><Badge variant={ride.bookingModeKey === 'Instant' ? 'default' : 'secondary'}>{ride.bookingModeKey === 'Instant' ? 'Instant' : 'Approval'}</Badge></div><CardTitle className="mt-3">{ride.origin} → {ride.campusDestination}</CardTitle><CardDescription>{ride.driverStudent?.fullName ?? 'Verified driver'} · {vehicle?.model ?? 'Vehicle'}</CardDescription></CardHeader><CardContent className="space-y-4 pt-5"><div className="flex justify-between"><div><p className="text-sm text-muted-foreground">Departure</p><p className="font-bold">{formatTripDate(ride.departureDateAndTime)}</p></div><div className="text-right"><p className="text-sm text-muted-foreground">Per seat</p><p className="text-xl font-bold">₹{ride.contributionAmount ?? 0}</p></div></div><div className="flex items-center justify-between rounded-lg bg-muted p-3 text-muted-foreground"><span className="flex items-center gap-2"><Users className="size-4" />{ride.availableSeats} seats</span><span className="flex items-center gap-2"><ShieldCheck className="size-4" />Verified</span></div><Button className="w-full" variant={ownRide ? 'outline' : 'default'} onClick={() => { if (ownRide) { navigate('/my-rides'); return; } setSelectedRide(ride); setSeatCount(1); }}>{ownRide ? 'Manage your ride' : <>Choose ride <ChevronRight className="size-4" /></>}</Button></CardContent></Card></motion.article>;
          })}</div>}
        </section>}

        {page === 'publish' && <section className="mx-auto max-w-4xl">
          <div className="mb-6"><Badge variant="secondary">Driver mode</Badge><h1 className="mt-2 text-2xl font-bold">Publish your empty seats</h1><p className="text-muted-foreground">Create one clear trip. Passengers provide their pickup area when booking.</p></div>
          <Card><CardContent className="p-6"><form onSubmit={publishRide} className="grid gap-5 md:grid-cols-2">
            <div className="md:col-span-2"><Label>Trip direction</Label><div className="mt-2 grid grid-cols-2 gap-3"><Button type="button" variant={publishDirection === 'ToCollege' ? 'default' : 'outline'} onClick={() => setPublishDirection('ToCollege')}>Going to college</Button><Button type="button" variant={publishDirection === 'FromCollege' ? 'default' : 'outline'} onClick={() => setPublishDirection('FromCollege')}>Coming from college</Button></div></div>
            <div><Label>Vehicle</Label><Select value={publishVehicle} onValueChange={(value: 'Car' | 'Bike') => setPublishVehicle(value)}><SelectTrigger className="mt-2 w-full"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="Car">Car</SelectItem><SelectItem value="Bike">Bike</SelectItem></SelectContent></Select></div>
            <div><Label>Booking decision</Label><Select value={bookingMode} onValueChange={(value: 'Approval' | 'Instant') => setBookingMode(value)}><SelectTrigger className="mt-2 w-full"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="Approval">I accept or decline</SelectItem><SelectItem value="Instant">Confirm instantly</SelectItem></SelectContent></Select></div>
            <div><Label htmlFor="area">{publishDirection === 'ToCollege' ? 'Starting area' : 'Drop-off area'}</Label><Input id="area" name="area" className="mt-2" placeholder="Area or landmark" /></div>
            <div><Label>College</Label><Input className="mt-2" value={identity.college} readOnly /></div>
            <div><Label>Travel date</Label><Popover><PopoverTrigger asChild><Button type="button" variant="outline" className="mt-2 w-full justify-start"><CalendarDays className="size-4" />{travelDate ? format(travelDate, 'dd MMM yyyy') : 'Choose date'}</Button></PopoverTrigger><PopoverContent className="w-auto p-0"><Calendar mode="single" selected={travelDate} onSelect={setTravelDate} disabled={(date: Date) => date < new Date(new Date().setHours(0, 0, 0, 0))} initialFocus /></PopoverContent></Popover></div>
            <div><Label>Departure time</Label><Select value={departureTime} onValueChange={setDepartureTime}><SelectTrigger className="mt-2 w-full"><Clock3 className="size-4" /><SelectValue /></SelectTrigger><SelectContent>{['06:30','07:00','07:30','08:00','08:30','15:30','16:00','16:30','17:00','17:30','18:00'].filter((time: string) => time).map((time: string) => <SelectItem key={time} value={time}>{format(new Date(`2026-01-01T${time}:00`), 'h:mm a')}</SelectItem>)}</SelectContent></Select></div>
            <div><Label htmlFor="seats">Empty seats</Label><Input id="seats" name="seats" type="number" min="1" max="6" defaultValue={publishVehicle === 'Bike' ? 1 : 3} disabled={publishVehicle === 'Bike'} className="mt-2" /><p className="mt-2 text-xs text-muted-foreground">Bikes offer one passenger seat.</p></div>
            <div><Label htmlFor="fee">Fee per seat</Label><div className="relative mt-2"><IndianRupee className="absolute left-3 top-2.5 size-4 text-muted-foreground" /><Input id="fee" name="fee" type="number" min="0" step="1" className="pl-9" placeholder="Driver-set amount" /></div></div>
            <div className="md:col-span-2 flex justify-end"><Button type="submit" disabled={createRide.isPending || createVehicle.isPending}><Plus className="size-4" />{createRide.isPending || createVehicle.isPending ? 'Publishing...' : 'Publish ride'}</Button></div>
          </form></CardContent></Card>
        </section>}

        {page === 'bookings' && <section><div className="mb-6"><Badge variant="secondary">Passenger mode</Badge><h1 className="mt-2 text-2xl font-bold">My bookings</h1><p className="text-muted-foreground">Track requests, confirmed seats, pickup areas, and fares.</p></div>{myBookings.length === 0 ? <Empty className="rounded-xl border py-16"><EmptyHeader><EmptyTitle>No bookings yet</EmptyTitle><EmptyDescription>Choose a ride to send your first request.</EmptyDescription></EmptyHeader></Empty> : <div className="grid gap-4 md:grid-cols-2">{myBookings.map((booking: Booking) => { const ride = rideFor(booking); return <Card key={booking.id}><CardHeader><div className="flex justify-between gap-3"><div><CardTitle>{booking.ride?.rideName ?? 'College ride'}</CardTitle><CardDescription>{ride ? formatTripDate(ride.departureDateAndTime) : 'Ride details unavailable'}</CardDescription></div><Badge variant={bookingBadge(booking.statusKey)}>{booking.statusKey}</Badge></div></CardHeader><CardContent><div className="space-y-2 text-sm"><p><MapPin className="mr-2 inline size-4" />{booking.pickupPoint ?? 'Pickup pending'}</p><p><Users className="mr-2 inline size-4" />{booking.seatsRequested} seat(s)</p><p><IndianRupee className="mr-2 inline size-4" />₹{booking.fareAmount}</p></div>{['Pending','Confirmed'].includes(booking.statusKey) && <><Separator className="my-4" /><Button size="sm" variant="outline" onClick={() => reviewBooking(booking, 'Cancelled')}>Cancel booking</Button></>}</CardContent></Card>; })}</div>}</section>}

        {page === 'rides' && <section><div className="mb-6"><Badge variant="secondary">Driver mode</Badge><h1 className="mt-2 text-2xl font-bold">My published rides</h1><p className="text-muted-foreground">Manage trips and respond to passenger pickup requests.</p></div><div className="grid gap-5 lg:grid-cols-[1.1fr_0.9fr]"><div className="space-y-4">{myRides.length === 0 ? <Empty className="rounded-xl border py-16"><EmptyHeader><EmptyTitle>No rides published</EmptyTitle><EmptyDescription>Publish empty seats for your next college commute.</EmptyDescription></EmptyHeader></Empty> : myRides.map((ride: Ride) => <Card key={ride.id}><CardHeader><div className="flex justify-between gap-3"><div><CardTitle>{ride.rideName}</CardTitle><CardDescription>{formatTripDate(ride.departureDateAndTime)}</CardDescription></div><Badge variant={ride.statusKey === 'Upcoming' ? 'default' : 'destructive'}>{ride.statusKey}</Badge></div></CardHeader><CardContent><div className="grid grid-cols-3 gap-3 text-center"><div className="rounded-lg bg-muted p-3 text-muted-foreground"><strong className="block text-lg text-foreground">{ride.availableSeats}/{ride.totalSeats}</strong>Seats</div><div className="rounded-lg bg-muted p-3 text-muted-foreground"><strong className="block text-lg text-foreground">₹{ride.contributionAmount}</strong>Per seat</div><div className="rounded-lg bg-muted p-3 text-muted-foreground"><strong className="block text-lg text-foreground">{ride.bookingModeKey}</strong>Mode</div></div>{ride.statusKey === 'Upcoming' && <div className="mt-4 text-right"><Button variant="destructive" size="sm" onClick={() => updateRide.mutate({ id: ride.id, changedFields: { statusKey: 'Cancelled', cancelledDateAndTime: new Date().toISOString() } }, { onSuccess: () => toast.success('Ride cancelled.') })}>Cancel ride</Button></div>}</CardContent></Card>)}</div><Card className="h-fit"><CardHeader><CardTitle>Pickup requests</CardTitle><CardDescription>Accept only when the pickup area and seats work.</CardDescription></CardHeader><CardContent className="space-y-3">{bookings.filter((booking: Booking) => booking.statusKey === 'Pending' && myRides.some((ride: Ride) => ride.id === booking.ride?.id)).map((booking: Booking) => <div key={booking.id} className="rounded-lg border p-3"><div className="flex justify-between gap-3"><div><p className="font-semibold">{booking.riderStudent?.fullName ?? 'Student'}</p><p className="text-sm text-muted-foreground">{booking.seatsRequested} seat(s) · ₹{booking.fareAmount}</p></div><IdCard className="size-5" /></div><p className="mt-3 text-sm"><MapPin className="mr-2 inline size-4" />{booking.pickupPoint}</p><div className="mt-3 flex gap-2"><Button size="sm" disabled={(rideFor(booking)?.availableSeats ?? 0) < booking.seatsRequested} onClick={() => reviewBooking(booking, 'Confirmed')}><Check className="size-4" />Accept</Button><Button size="sm" variant="outline" onClick={() => reviewBooking(booking, 'Rejected')}><X className="size-4" />Decline</Button></div></div>)}</CardContent></Card></div></section>}
      </main>

      <Dialog open={Boolean(selectedRide)} onOpenChange={(open: boolean) => { if (!open) setSelectedRide(undefined); }}>
        <DialogContent className="sm:max-w-xl">{selectedRide && <><DialogHeader><DialogTitle>Request this ride</DialogTitle><DialogDescription>{selectedRide.origin} → {selectedRide.campusDestination} · {formatTripDate(selectedRide.departureDateAndTime)}</DialogDescription></DialogHeader><div className="space-y-5"><div className="grid grid-cols-2 gap-3"><div className="rounded-xl bg-primary p-4 text-primary-foreground"><p className="text-sm">Fee per seat</p><p className="text-2xl font-bold">₹{selectedRide.contributionAmount ?? 0}</p></div><div className="rounded-xl bg-secondary p-4 text-secondary-foreground"><p className="text-sm">Seats available</p><p className="text-2xl font-bold">{selectedRide.availableSeats}</p></div></div><div><Label htmlFor="pickup">Your pickup area</Label><Input id="pickup" className="mt-2" value={pickupArea} onChange={(event: ChangeEvent<HTMLInputElement>) => setPickupArea(event.target.value)} placeholder="Area or nearby landmark" /></div><div><Label>Seats</Label><Select value={String(seatCount)} onValueChange={(value: string) => setSeatCount(Number(value))}><SelectTrigger className="mt-2 w-full"><SelectValue /></SelectTrigger><SelectContent>{Array.from({ length: Math.max(0, selectedRide.availableSeats) }, (_item: unknown, index: number) => index + 1).filter((count: number) => count > 0).map((count: number) => <SelectItem key={count} value={String(count)}>{count} seat{count > 1 ? 's' : ''} · ₹{count * (selectedRide.contributionAmount ?? 0)}</SelectItem>)}</SelectContent></Select></div><div className="flex items-center justify-between rounded-xl border p-4"><span className="font-semibold">Total fare</span><strong className="text-xl">₹{seatCount * (selectedRide.contributionAmount ?? 0)}</strong></div><Button className="w-full" disabled={!pickupArea.trim() || createBooking.isPending} onClick={bookRide}>{createBooking.isPending ? 'Sending...' : selectedRide.bookingModeKey === 'Instant' ? 'Book now' : 'Send request'}</Button></div></>}</DialogContent>
      </Dialog>
    </div>
  );
}

export default CampusPoolPage;