import { useState, type ChangeEvent, type FormEvent } from 'react';
import { ArrowRight, BadgeCheck, Building2, CalendarIcon, IdCard, Route, ShieldCheck, UserRound } from 'lucide-react';
import { addYears, format } from 'date-fns';
import { motion } from 'motion/react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';

const chennaiColleges = [
  'Anna University, CEG Campus',
  'Indian Institute of Technology Madras',
  'Loyola College',
  'Madras Christian College',
  'Presidency College',
  'Sathyabama Institute of Science and Technology',
  'SRM Institute of Science and Technology',
  'Sri Sairam Engineering College',
  'Stella Maris College',
  'University of Madras',
  'Vel Tech Rangarajan Dr. Sagunthala R&D Institute',
  'Vellore Institute of Technology, Chennai',
  'Other Chennai college',
];

export type CollegeIdentity = {
  studentName: string;
  college: string;
  registerNumber: string;
  idExpiry: string;
  profileId?: string;
};

type CollegeIdGateProps = {
  onVerified: (identity: CollegeIdentity) => void | Promise<void>;
};

export function CollegeIdGate({ onVerified }: CollegeIdGateProps) {
  const [studentName, setStudentName] = useState('');
  const [college, setCollege] = useState('');
  const [registerNumber, setRegisterNumber] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [idExpiry, setIdExpiry] = useState<Date>();
  const today = new Date();
  const earliestExpiry = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const latestExpiry = addYears(earliestExpiry, 6);

  const verifyId = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const name = studentName.trim();
    const register = registerNumber.trim();
    if (!name || !college || !register || !idExpiry) {
      toast.error('Complete every college ID field.');
      return;
    }
    const verificationDate = new Date();
    verificationDate.setHours(0, 0, 0, 0);
    if (idExpiry < verificationDate) {
      toast.error('Your college ID has expired.');
      return;
    }
    setIsVerifying(true);
    try {
      await onVerified({ studentName: name, college, registerNumber: register.toUpperCase(), idExpiry: idExpiry.toISOString() });
      toast.success('College ID verified. Welcome to CampusPool.');
    } catch (error: unknown) {
      toast.error(error instanceof Error ? error.message : 'College ID verification failed.');
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="grid min-h-screen lg:grid-cols-[1.05fr_0.95fr]">
        <section className="relative hidden overflow-hidden bg-sidebar text-sidebar-foreground lg:flex lg:flex-col lg:justify-between lg:p-12">
          <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)', backgroundSize: '28px 28px' }} />
          <div className="relative flex items-center gap-3">
            <span className="flex size-11 items-center justify-center rounded-xl bg-sidebar-primary text-sidebar-primary-foreground"><Route className="size-6" /></span>
            <div><p className="text-lg font-bold">CampusPool Chennai</p><p className="text-sm">College-verified student commutes</p></div>
          </div>
          <div className="relative max-w-xl">
            <span className="inline-flex rounded-full bg-sidebar-accent px-3 py-1 text-sm font-semibold text-sidebar-accent-foreground">Students on the same route</span>
            <h1 className="mt-5 text-4xl font-bold leading-tight">Share the road with verified college students.</h1>
            <p className="mt-4 max-w-lg text-lg">Confirm your active college ID before discovering cars, bikes, and routes to campuses across Chennai.</p>
            <div className="mt-10 grid grid-cols-3 gap-3">
              <div className="rounded-xl border border-sidebar-border bg-sidebar-accent p-4 text-sidebar-accent-foreground"><IdCard className="mb-3 size-5" /><p className="font-semibold">ID checked</p></div>
              <div className="rounded-xl border border-sidebar-border bg-sidebar-accent p-4 text-sidebar-accent-foreground"><Building2 className="mb-3 size-5" /><p className="font-semibold">College network</p></div>
              <div className="rounded-xl border border-sidebar-border bg-sidebar-accent p-4 text-sidebar-accent-foreground"><Route className="mb-3 size-5" /><p className="font-semibold">Route matched</p></div>
            </div>
          </div>
          <p className="relative text-sm">For currently enrolled students at Chennai colleges.</p>
        </section>

        <main className="flex items-center justify-center p-5 sm:p-10">
          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35, ease: 'easeOut' as const }} className="w-full max-w-lg">
            <div className="mb-7 flex items-center gap-3 lg:hidden">
              <span className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground"><Route className="size-5" /></span>
              <p className="font-bold">CampusPool Chennai</p>
            </div>
            <Card>
              <CardContent className="p-6 sm:p-8">
                <form onSubmit={verifyId} className="space-y-6">
                  <div>
                    <span className="mb-4 flex size-12 items-center justify-center rounded-xl bg-primary text-primary-foreground"><IdCard className="size-6" /></span>
                    <h2 className="text-2xl font-bold">Verify your college ID</h2>
                    <p className="mt-2 text-muted-foreground">Enter the details printed on your current student ID.</p>
                  </div>
                  <div className="grid gap-5 sm:grid-cols-2">
                    <div className="sm:col-span-2"><Label htmlFor="student-name">Student name</Label><div className="relative mt-2"><UserRound className="absolute left-3 top-2.5 size-4 text-muted-foreground" /><Input id="student-name" className="pl-9" autoComplete="name" placeholder="Name on college ID" value={studentName} onChange={(event: ChangeEvent<HTMLInputElement>) => setStudentName(event.target.value)} /></div></div>
                    <div className="sm:col-span-2"><Label>Chennai college</Label><Select value={college} onValueChange={setCollege}><SelectTrigger className="mt-2 w-full"><SelectValue placeholder="Select your college" /></SelectTrigger><SelectContent>{chennaiColleges.filter((item: string) => item).map((item: string) => <SelectItem key={item} value={item}>{item}</SelectItem>)}</SelectContent></Select></div>
                    <div><Label htmlFor="register-number">Register number</Label><Input id="register-number" className="mt-2 uppercase" autoComplete="off" placeholder="e.g. 22CSE1048" value={registerNumber} onChange={(event: ChangeEvent<HTMLInputElement>) => setRegisterNumber(event.target.value)} /></div>
                    <div className="sm:col-span-2">
                      <div className="flex items-end justify-between gap-3">
                        <div>
                          <Label>ID valid until</Label>
                          <p className="mt-1 text-xs text-muted-foreground">Choose the expiry printed on your ID.</p>
                        </div>
                        {idExpiry && <Button type="button" variant="ghost" size="sm" onClick={() => setIdExpiry(undefined)}>Clear</Button>}
                      </div>
                      <div className="mt-3 grid grid-cols-3 gap-2">
                        {[1, 2, 3].map((years: number) => (
                          <Button key={years} type="button" variant="secondary" size="sm" onClick={() => setIdExpiry(addYears(earliestExpiry, years))}>
                            +{years} {years === 1 ? 'year' : 'years'}
                          </Button>
                        ))}
                      </div>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button type="button" variant="outline" className={cn('mt-2 h-11 w-full justify-between font-normal', !idExpiry && 'text-muted-foreground')}>
                            <span className="flex items-center gap-2"><CalendarIcon className="size-4" />{idExpiry ? format(idExpiry, 'dd MMMM yyyy') : 'Choose exact expiry date'}</span>
                            <span className="text-xs">Open calendar</span>
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent align="start" className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={idExpiry}
                            onSelect={setIdExpiry}
                            disabled={(date: Date) => date < earliestExpiry || date > latestExpiry}
                            captionLayout="dropdown"
                            startMonth={earliestExpiry}
                            endMonth={latestExpiry}
                            defaultMonth={idExpiry ?? addYears(earliestExpiry, 1)}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      {idExpiry && <p className="mt-2 text-sm font-medium"><BadgeCheck className="mr-1.5 inline size-4" />Valid until {format(idExpiry, 'dd MMM yyyy')}</p>}
                    </div>
                  </div>
                  <div className="flex gap-3 rounded-lg bg-secondary p-4 text-secondary-foreground"><ShieldCheck className="mt-0.5 size-5 shrink-0" /><div><p className="text-sm font-semibold">Local verification</p><p className="mt-1 text-xs">Your details are validated in this app preview and are not sent to your college.</p></div></div>
                  <Button type="submit" className="w-full" disabled={isVerifying}>{isVerifying ? 'Preparing your profile...' : 'Verify and enter'} {!isVerifying && <ArrowRight className="size-4" />}</Button>
                  <p className="text-center text-xs text-muted-foreground"><BadgeCheck className="mr-1 inline size-3" />Only active college IDs can access student rides.</p>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        </main>
      </div>
    </div>
  );
}
