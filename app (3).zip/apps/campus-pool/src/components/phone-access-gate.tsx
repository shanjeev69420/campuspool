import { useState, type ChangeEvent, type FormEvent } from 'react';
import { ArrowRight, Building2, CheckCircle2, LockKeyhole, MessageSquareText, Phone, Route, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const chennaiColleges = [
  'Anna University, CEG Campus',
  'Indian Institute of Technology Madras',
  'Loyola College',
  'Madras Christian College',
  'Presidency College',
  'Sathyabama Institute of Science and Technology',
  'SRM Institute of Science and Technology',
  'Sri Sairam Engineering College',
  'Stella Maris College',
  'University of Madras',
  'Vel Tech Rangarajan Dr. Sagunthala R&D Institute',
  'Vellore Institute of Technology, Chennai',
  'Other Chennai college',
];

const previewOtp = '246810';

type PhoneAccessGateProps = {
  onVerified: (phone: string, college: string) => void;
};

export function PhoneAccessGate({ onVerified }: PhoneAccessGateProps) {
  const [step, setStep] = useState<'phone' | 'verify' | 'college'>('phone');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [college, setCollege] = useState('');
  const cleanPhone = phone.replace(/\D/g, '').slice(-10);

  const requestOtp = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
      toast.error('Enter a valid 10-digit Indian mobile number.');
      return;
    }
    setPhone(cleanPhone);
    setStep('verify');
    toast.info('SMS preview code generated.');
  };

  const verifyOtp = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (otp !== previewOtp) {
      toast.error('The verification code is incorrect.');
      return;
    }
    setStep('college');
    toast.success('Phone number verified.');
  };

  const finishAccess = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!college) {
      toast.error('Select your Chennai college.');
      return;
    }
    onVerified(`+91 ${phone}`, college);
    toast.success('Welcome to CampusPool.');
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="grid min-h-screen lg:grid-cols-[1.05fr_0.95fr]">
        <section className="relative hidden overflow-hidden bg-sidebar text-sidebar-foreground lg:flex lg:flex-col lg:justify-between lg:p-12">
          <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)', backgroundSize: '28px 28px' }} />
          <div className="relative flex items-center gap-3">
            <span className="flex size-11 items-center justify-center rounded-xl bg-sidebar-primary text-sidebar-primary-foreground"><Route className="size-6" /></span>
            <div><p className="text-lg font-bold">CampusPool Chennai</p><p className="text-sm">Verified student commutes</p></div>
          </div>
          <div className="relative max-w-xl">
            <Badge variant="secondary">Students on the same route</Badge>
            <h1 className="mt-5 text-4xl font-bold leading-tight">A safer way to share every ride to college.</h1>
            <p className="mt-4 max-w-lg text-lg">Verify your mobile number, choose your Chennai college, and find students travelling your way.</p>
            <div className="mt-10 grid grid-cols-3 gap-3">
              <div className="rounded-xl border border-sidebar-border bg-sidebar-accent text-sidebar-accent-foreground p-4"><ShieldCheck className="mb-3 size-5" /><p className="font-semibold">Phone verified</p></div>
              <div className="rounded-xl border border-sidebar-border bg-sidebar-accent text-sidebar-accent-foreground p-4"><Building2 className="mb-3 size-5" /><p className="font-semibold">College network</p></div>
              <div className="rounded-xl border border-sidebar-border bg-sidebar-accent text-sidebar-accent-foreground p-4"><Route className="mb-3 size-5" /><p className="font-semibold">Route matched</p></div>
            </div>
          </div>
          <p className="relative text-sm">Available to students across Chennai colleges.</p>
        </section>

        <main className="flex items-center justify-center p-5 sm:p-10">
          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35, ease: 'easeOut' as const }} className="w-full max-w-md">
            <div className="mb-7 flex items-center gap-3 lg:hidden">
              <span className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground"><Route className="size-5" /></span>
              <p className="font-bold">CampusPool Chennai</p>
            </div>
            <div className="mb-6 flex gap-2" aria-label="Verification progress">
              {['phone', 'verify', 'college'].map((item: string, index: number) => {
                const activeIndex = step === 'phone' ? 0 : step === 'verify' ? 1 : 2;
                return <span key={item} className={`h-1.5 flex-1 rounded-full ${index <= activeIndex ? 'bg-primary' : 'bg-muted'}`} />;
              })}
            </div>

            <Card>
              <CardContent className="p-6 sm:p-8">
                {step === 'phone' && <form onSubmit={requestOtp} className="space-y-6">
                  <div><span className="mb-4 flex size-12 items-center justify-center rounded-xl bg-primary text-primary-foreground"><Phone className="size-5" /></span><h2 className="text-2xl font-bold">Verify your mobile</h2><p className="mt-2 text-muted-foreground">Use your Indian mobile number to access student rides.</p></div>
                  <div><Label htmlFor="phone">Mobile number</Label><div className="mt-2 flex"><span className="flex items-center rounded-l-md border border-r-0 bg-muted text-muted-foreground px-3 text-sm font-semibold">+91</span><Input id="phone" inputMode="numeric" autoComplete="tel" className="rounded-l-none" placeholder="98765 43210" value={phone} onChange={(event: ChangeEvent<HTMLInputElement>) => setPhone(event.target.value.replace(/\D/g, '').slice(0, 10))} /></div></div>
                  <div className="rounded-lg border-l-4 border-l-accent-foreground bg-card text-card-foreground p-3 text-sm"><strong>SMS provider setup pending.</strong> Preview verification is enabled for this build.</div>
                  <Button type="submit" className="w-full">Send OTP <ArrowRight className="size-4" /></Button>
                  <p className="text-center text-xs text-muted-foreground"><LockKeyhole className="mr-1 inline size-3" />Your number is used only for ride access and coordination.</p>
                </form>}

                {step === 'verify' && <form onSubmit={verifyOtp} className="space-y-6">
                  <div><span className="mb-4 flex size-12 items-center justify-center rounded-xl bg-primary text-primary-foreground"><MessageSquareText className="size-5" /></span><h2 className="text-2xl font-bold">Enter verification code</h2><p className="mt-2 text-muted-foreground">Code sent to +91 {phone.slice(0, 5)} {phone.slice(5)}.</p></div>
                  <div><Label htmlFor="otp">6-digit OTP</Label><Input id="otp" inputMode="numeric" autoComplete="one-time-code" maxLength={6} className="mt-2 text-center text-2xl tracking-[0.45em]" placeholder="000000" value={otp} onChange={(event: ChangeEvent<HTMLInputElement>) => setOtp(event.target.value.replace(/\D/g, '').slice(0, 6))} /></div>
                  <div className="rounded-lg bg-accent text-accent-foreground p-4"><p className="text-sm font-semibold">Preview verification code</p><p className="mt-1 text-2xl font-bold tracking-[0.3em]">{previewOtp}</p></div>
                  <Button type="submit" className="w-full" disabled={otp.length !== 6}>Verify number <CheckCircle2 className="size-4" /></Button>
                  <Button type="button" variant="ghost" className="w-full" onClick={() => { setOtp(''); setStep('phone'); }}>Change mobile number</Button>
                </form>}

                {step === 'college' && <form onSubmit={finishAccess} className="space-y-6">
                  <div><span className="mb-4 flex size-12 items-center justify-center rounded-xl bg-primary text-primary-foreground"><Building2 className="size-5" /></span><h2 className="text-2xl font-bold">Choose your college</h2><p className="mt-2 text-muted-foreground">This helps us show relevant Chennai campus routes.</p></div>
                  <div><Label>Chennai college</Label><Select value={college} onValueChange={setCollege}><SelectTrigger className="mt-2 w-full"><SelectValue placeholder="Select your college" /></SelectTrigger><SelectContent>{chennaiColleges.filter((item: string) => item).map((item: string) => <SelectItem key={item} value={item}>{item}</SelectItem>)}</SelectContent></Select></div>
                  <div className="flex items-center gap-3 rounded-lg bg-secondary text-secondary-foreground p-3"><CheckCircle2 className="size-5" /><div><p className="text-sm font-semibold">Mobile verified</p><p className="text-xs">+91 {phone.slice(0, 5)} {phone.slice(5)}</p></div></div>
                  <Button type="submit" className="w-full" disabled={!college}>Enter CampusPool <ArrowRight className="size-4" /></Button>
                </form>}
              </CardContent>
            </Card>
          </motion.div>
        </main>
      </div>
    </div>
  );
}
