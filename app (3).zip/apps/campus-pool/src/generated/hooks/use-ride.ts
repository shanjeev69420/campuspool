import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { RideService } from "../services/ride-service";
import type { Ride } from "../models/ride-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all Ride records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, rideName, availableSeats, bookingModeKey, campusDestination, cancelledDateAndTime, completedDateAndTime, contributionAmount, createdDateAndTime, departureDateAndTime, origin, rideDirectionKey, statusKey, totalSeats
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useRideList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["ride-list", options],
    queryFn: () => RideService.getAll(options),
  });
}

/**
 * Retrieve a single Ride record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useRide(id: string) {
  return useQuery({
    queryKey: ["ride", id],
    queryFn: () => RideService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new Ride record.
 * @remarks Form validation: use CreateRideSchema with zodResolver for type-safe create forms
 */
export function useCreateRide() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<Ride, "id">) => RideService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["ride-list"] });
    },
  });
}

/**
 * Update an existing Ride record.
 * @remarks Form validation: use UpdateRideSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateRide() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<Ride, "id">>;
    }) => RideService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["ride-list"] });
      client.invalidateQueries({ queryKey: ["ride", variables.id] });
    },
  });
}

/**
 * Delete a Ride record by its unique identifier.
 */
export function useDeleteRide() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => RideService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["ride-list"] });
      client.invalidateQueries({ queryKey: ["ride", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const Ride_DATA_SOURCE_TYPE = 'InMemory' as const;

export { RideSchema, CreateRideSchema, UpdateRideSchema } from "../validators/ride-validator";
export type { RideInput, CreateRideInput, UpdateRideInput } from "../validators/ride-validator";