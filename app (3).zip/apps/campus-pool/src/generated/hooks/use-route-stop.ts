import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { RouteStopService } from "../services/route-stop-service";
import type { RouteStop } from "../models/route-stop-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all RouteStop records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, stopName, estimatedPickupDateAndTime, locationNote, sequenceNumber
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useRouteStopList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["routeStop-list", options],
    queryFn: () => RouteStopService.getAll(options),
  });
}

/**
 * Retrieve a single RouteStop record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useRouteStop(id: string) {
  return useQuery({
    queryKey: ["routeStop", id],
    queryFn: () => RouteStopService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new RouteStop record.
 * @remarks Form validation: use CreateRouteStopSchema with zodResolver for type-safe create forms
 */
export function useCreateRouteStop() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<RouteStop, "id">) => RouteStopService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["routeStop-list"] });
    },
  });
}

/**
 * Update an existing RouteStop record.
 * @remarks Form validation: use UpdateRouteStopSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateRouteStop() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<RouteStop, "id">>;
    }) => RouteStopService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["routeStop-list"] });
      client.invalidateQueries({ queryKey: ["routeStop", variables.id] });
    },
  });
}

/**
 * Delete a RouteStop record by its unique identifier.
 */
export function useDeleteRouteStop() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => RouteStopService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["routeStop-list"] });
      client.invalidateQueries({ queryKey: ["routeStop", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const RouteStop_DATA_SOURCE_TYPE = 'InMemory' as const;

export { RouteStopSchema, CreateRouteStopSchema, UpdateRouteStopSchema } from "../validators/route-stop-validator";
export type { RouteStopInput, CreateRouteStopInput, UpdateRouteStopInput } from "../validators/route-stop-validator";