import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { StudentProfileService } from "../services/student-profile-service";
import type { StudentProfile } from "../models/student-profile-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all StudentProfile records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, fullName, collegeName, email
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useStudentProfileList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["studentProfile-list", options],
    queryFn: () => StudentProfileService.getAll(options),
  });
}

/**
 * Retrieve a single StudentProfile record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useStudentProfile(id: string) {
  return useQuery({
    queryKey: ["studentProfile", id],
    queryFn: () => StudentProfileService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new StudentProfile record.
 * @remarks Form validation: use CreateStudentProfileSchema with zodResolver for type-safe create forms
 */
export function useCreateStudentProfile() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<StudentProfile, "id">) => StudentProfileService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["studentProfile-list"] });
    },
  });
}

/**
 * Update an existing StudentProfile record.
 * @remarks Form validation: use UpdateStudentProfileSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateStudentProfile() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<StudentProfile, "id">>;
    }) => StudentProfileService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["studentProfile-list"] });
      client.invalidateQueries({ queryKey: ["studentProfile", variables.id] });
    },
  });
}

/**
 * Delete a StudentProfile record by its unique identifier.
 */
export function useDeleteStudentProfile() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => StudentProfileService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["studentProfile-list"] });
      client.invalidateQueries({ queryKey: ["studentProfile", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const StudentProfile_DATA_SOURCE_TYPE = 'InMemory' as const;

export { StudentProfileSchema, CreateStudentProfileSchema, UpdateStudentProfileSchema } from "../validators/student-profile-validator";
export type { StudentProfileInput, CreateStudentProfileInput, UpdateStudentProfileInput } from "../validators/student-profile-validator";