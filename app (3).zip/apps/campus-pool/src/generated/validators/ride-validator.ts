import { z } from 'zod';

/**
 * Zod schema for Ride validation
 */
export const RideSchema = z.object({
  id: z.string().uuid(),
  rideName: z.string().min(1, { message: "Ride Name is required" }),
  availableSeats: z.number().int(),
  bookingModeKey: z.enum(['Instant', 'Approval']),
  campusDestination: z.string().min(1, { message: "Campus Destination is required" }),
  cancelledDateAndTime: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").optional(),
  completedDateAndTime: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").optional(),
  contributionAmount: z.number(),
  createdDateAndTime: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").min(1, { message: "Created Date and Time is required" }),
  departureDateAndTime: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").min(1, { message: "Departure Date and Time is required" }),
  driverStudent: z.object({ id: z.string().uuid(), fullName: z.string() }),
  origin: z.string().min(1, { message: "Origin is required" }),
  rideDirectionKey: z.enum(['ToCollege', 'FromCollege']),
  statusKey: z.enum(['Upcoming', 'Completed', 'Cancelled']),
  totalSeats: z.number().int(),
  vehicle: z.object({ id: z.string().uuid(), vehicleName: z.string() }),
});

/**
 * Schema for creating a new Ride (omits system-generated ID)
 */
export const CreateRideSchema = RideSchema.omit({ id: true });

/**
 * Schema for updating an existing Ride
 */
export const UpdateRideSchema = RideSchema;

export type RideInput = z.infer<typeof RideSchema>;
export type CreateRideInput = z.infer<typeof CreateRideSchema>;
export type UpdateRideInput = z.infer<typeof UpdateRideSchema>;