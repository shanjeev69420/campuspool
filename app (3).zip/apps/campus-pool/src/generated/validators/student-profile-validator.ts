import { z } from 'zod';

/**
 * Zod schema for StudentProfile validation
 */
export const StudentProfileSchema = z.object({
  id: z.string().uuid(),
  fullName: z.string().min(1, { message: "Full Name is required" }),
  collegeName: z.string().min(1, { message: "College Name is required" }),
  email: z.string().email().min(1, { message: "Email is required" }),
});

/**
 * Schema for creating a new StudentProfile (omits system-generated ID)
 */
export const CreateStudentProfileSchema = StudentProfileSchema.omit({ id: true });

/**
 * Schema for updating an existing StudentProfile
 */
export const UpdateStudentProfileSchema = StudentProfileSchema;

export type StudentProfileInput = z.infer<typeof StudentProfileSchema>;
export type CreateStudentProfileInput = z.infer<typeof CreateStudentProfileSchema>;
export type UpdateStudentProfileInput = z.infer<typeof UpdateStudentProfileSchema>;