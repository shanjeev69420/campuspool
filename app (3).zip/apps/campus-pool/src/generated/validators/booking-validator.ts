import { z } from 'zod';

/**
 * Zod schema for Booking validation
 */
export const BookingSchema = z.object({
  id: z.string().uuid(),
  bookingName: z.string().min(1, { message: "Booking Name is required" }),
  cancelledDateAndTime: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").optional(),
  completedDateAndTime: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").optional(),
  fareAmount: z.number(),
  pickupPoint: z.string().optional(),
  requestedDateAndTime: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").min(1, { message: "Requested Date and Time is required" }),
  reviewedBy: z.object({ id: z.string().uuid(), fullName: z.string() }).optional(),
  reviewedDateAndTime: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").optional(),
  ride: z.object({ id: z.string().uuid(), rideName: z.string() }),
  riderStudent: z.object({ id: z.string().uuid(), fullName: z.string() }),
  seatsRequested: z.number().int(),
  statusKey: z.enum(['Pending', 'Confirmed', 'Rejected', 'Completed', 'Cancelled']),
});

/**
 * Schema for creating a new Booking (omits system-generated ID)
 */
export const CreateBookingSchema = BookingSchema.omit({ id: true });

/**
 * Schema for updating an existing Booking
 */
export const UpdateBookingSchema = BookingSchema;

export type BookingInput = z.infer<typeof BookingSchema>;
export type CreateBookingInput = z.infer<typeof CreateBookingSchema>;
export type UpdateBookingInput = z.infer<typeof UpdateBookingSchema>;