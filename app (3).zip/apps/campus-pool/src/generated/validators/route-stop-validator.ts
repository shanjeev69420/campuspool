import { z } from 'zod';

/**
 * Zod schema for RouteStop validation
 */
export const RouteStopSchema = z.object({
  id: z.string().uuid(),
  stopName: z.string().min(1, { message: "Stop Name is required" }),
  estimatedPickupDateAndTime: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").min(1, { message: "Estimated Pickup Date and Time is required" }),
  locationNote: z.string().optional(),
  ride: z.object({ id: z.string().uuid(), rideName: z.string() }),
  sequenceNumber: z.number().int(),
});

/**
 * Schema for creating a new RouteStop (omits system-generated ID)
 */
export const CreateRouteStopSchema = RouteStopSchema.omit({ id: true });

/**
 * Schema for updating an existing RouteStop
 */
export const UpdateRouteStopSchema = RouteStopSchema;

export type RouteStopInput = z.infer<typeof RouteStopSchema>;
export type CreateRouteStopInput = z.infer<typeof CreateRouteStopSchema>;
export type UpdateRouteStopInput = z.infer<typeof UpdateRouteStopSchema>;