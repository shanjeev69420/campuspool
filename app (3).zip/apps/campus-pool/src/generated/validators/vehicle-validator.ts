import { z } from 'zod';

/**
 * Zod schema for Vehicle validation
 */
export const VehicleSchema = z.object({
  id: z.string().uuid(),
  vehicleName: z.string().min(1, { message: "Vehicle Name is required" }),
  color: z.string().min(1, { message: "Color is required" }),
  imageUrl: z.string().optional(),
  make: z.string().min(1, { message: "Make is required" }),
  model: z.string().min(1, { message: "Model is required" }),
  ownerStudent: z.object({ id: z.string().uuid(), fullName: z.string() }),
  passengerCapacity: z.number().int(),
  registrationNumber: z.string().min(1, { message: "Registration Number is required" }),
  vehicleTypeKey: z.enum(['Car', 'Bike']),
});

/**
 * Schema for creating a new Vehicle (omits system-generated ID)
 */
export const CreateVehicleSchema = VehicleSchema.omit({ id: true });

/**
 * Schema for updating an existing Vehicle
 */
export const UpdateVehicleSchema = VehicleSchema;

export type VehicleInput = z.infer<typeof VehicleSchema>;
export type CreateVehicleInput = z.infer<typeof CreateVehicleSchema>;
export type UpdateVehicleInput = z.infer<typeof UpdateVehicleSchema>;